
# HOMES登記連携 Streamlit アプリ

## 🔧 セットアップ方法

1. `streamlit_app.py` を Streamlit Cloud にアップロード
2. `.streamlit/secrets.toml` に認証情報を設定（例は `secrets.toml.example` を参照）
3. スプレッドシートURLとGoogleサービスアカウント認証を忘れずに
