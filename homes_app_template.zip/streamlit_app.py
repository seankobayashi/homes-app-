
import streamlit as st
st.title("HOMES登記連携アプリ")
st.write("準備中のテンプレートコードです")
